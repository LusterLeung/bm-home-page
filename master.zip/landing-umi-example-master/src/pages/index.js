import Home from '../Home';

export default function () {
  return (
    <Home />
  );
}
