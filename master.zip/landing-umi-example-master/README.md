# landing-umi-example

详细使用请查看 landing 里的 [use in umi](https://landing.ant.design/docs/use/umi)
